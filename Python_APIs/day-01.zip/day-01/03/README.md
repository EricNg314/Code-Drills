# API Practice #

### Practicing api calls and grabbing tvShows from a tv api ###

- Tv api documentation 
[Check out this link](http://www.tvmaze.com/api)