# API Practice #

### Practicing api calls and grabbing doggy images from a dog api ###

- Dog api documentation
[Check out this link](https://dog.ceo/dog-api/)

- Making ajax call to a dog image api
- Using the response to find other data.
