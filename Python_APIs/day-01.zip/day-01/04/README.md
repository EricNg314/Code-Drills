# Nested List Access #

### This activity we will be playing with accessing, manipulating, and building dictionaries and lists from targeted Nested values. ###