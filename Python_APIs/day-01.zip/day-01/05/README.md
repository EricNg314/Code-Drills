# More Nested List Access #

### This activity we will, again, be playing with accessing, manipulating, and building dictionaries and lists from targeted Nested values. ###