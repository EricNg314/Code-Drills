# API Practice #

### Practicing api calls and grabbing responses ###

- A deck of cards    
[Check out this link](http://deckofcardsapi.com/)

- Making ajax call to a deck of cards api
- Using the response to find other data.
