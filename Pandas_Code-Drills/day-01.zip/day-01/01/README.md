# CSV and Functions

In a clean and simple interface, this is a fun task for you to exercise your mind by reading a csv and running functions in your csv loops.


## Instructions:
You'll be creating a random number and searching the Phrase.csv file for a matching row id.

Once a matching number is found, print out the current row's information and previous row's information using two different functions.

If nothing was found, then print out a message stating it was not found and the row id.

