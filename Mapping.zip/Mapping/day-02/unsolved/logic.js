// Create the map object, and have its default display be the United States

  // Add the tile layer to the map with a map id of `mapbox-streets-v6`
    
  // Query URL
  var url = "https://data.nasa.gov/resource/gh4g-9sfh.json";

  // Create a variable to change the marker icons

// Grab the data with d3

  // Create a new marker cluster group

  // Loop through data

    // Set the data location property to a variable

    // Check for location property

      // Add a new marker to the cluster group and bind a pop-up, each popup should have the name of the meteorite and the year it fell

  // Add our marker cluster layer to the map