# Connect to Database and Simple Query
We will be creating a basic connection to an existing database of your choice from MySQL and using pandas to query.

# Includes:
* Connecting to database using either pymysql or sqlalchemy module.
* Simple query using panda's read_sql method.
* Printing the resulting query.