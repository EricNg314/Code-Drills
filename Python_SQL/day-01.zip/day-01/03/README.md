# Garage With Many Cars
In the following exercise, we'll be creating a sql database that includes two tables with a garage and cars associated to a particular garage.


# Includes:
Usage of module sqlalchemy to do the following:
* Connect to a database file
* Create/Drop a database
* Create a table.
  * Column types
  * Foreign key
* Using class constructor
  * Add data to tables
* Simple query of a table and print.
