# Avocado Bar Chart

In this exercise you'll be learning to create a simple bar chart with the provided avocado data.

## This includes:
  - Using numpy and creating a chart area with matplotlib
    - Setting up the axis
    - Adding data to chart area
    - Adding labels and titles
    - Saving the chart for outside reference.
