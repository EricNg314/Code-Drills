# Top School Scores Chart

In this exercise you'll be learning to create a bar chart with the provided world ranking for school data.

## This includes:
  - Using numpy, matplotlib, and pandas
    - Importing csv data
    - Creating a new dataframe with a calculation.
    - Sorting the calcultion
    - Setting up the axis
    - Adding data to chart area
    - Adding labels and titles
    - Saving the chart for outside reference.
